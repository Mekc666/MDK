function start(cells) {
	let i = 0; //Счетчик ходов	
	for (let cell of cells) { //Пока все ячейки не заполнены
		cell.addEventListener('click', function step() { //При нажатии на ячейку активируется функция
			if (i % 2 == 0) { //Взятие остатка чтобы определять ходы
				this.innerHTML = 'X'; //Если остаток 0
			} else {
				this.innerHTML = '0'; //Если остаток 1
			}
			this.removeEventListener('click', step); //Удаляет функцию у ячейки
			if (isVictory(cells)) { //Если есть выигрышная комбинация
				alert("Победили "+this.innerHTML); //Выводим победителя
			}
			else if (i == 8) {
				alert('ничья'); //Иначе выводим ничью
			}			
			i++;
		});
	}
	}
	function isVictory(cells) { //Функция определения победы
	let combs = [ //Выйгрышные комбинации
		[0, 1, 2],
		[3, 4, 5],
		[6, 7, 8],
		[0, 3, 6],
		[1, 4, 7],
		[2, 5, 8],
		[0, 4, 8],
		[2, 4, 6],
	];
	for (let comb of combs) { //Перебор выйгрышных комбинаций
		if ( 	//Если одна из выйгрышных комбинаций совпадает
			cells[comb[0]].innerHTML == cells[comb[1]].innerHTML &&
			cells[comb[1]].innerHTML == cells[comb[2]].innerHTML &&
			cells[comb[0]].innerHTML != ''
		) {
			return true; //Возвращаем истину
		}
	}
	return false; //Иначе возвращаем ложь
	}
	let cells = document.querySelectorAll('#field td') //Выбираем блоки из таблицы
	start(cells) //Запускает функцию