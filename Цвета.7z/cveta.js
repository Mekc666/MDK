let userSize = prompt("Выберите размер поля (Вписать одну цифру)");  //Размер поля
let table = document.getElementById('feld');   //Получаем данные тега таблицы
let colors = ['red', 'green', 'blue'];   //Задаем цвета ячеек
let stepCount = 0;   //Количествво шагов

function getRandomInt(max) {
	return Math.floor(Math.random() * (max + 1));  //Функция рандомного выбора
}

function random(arr) {
	return arr[getRandomInt(arr.length - 1)]; //Функция рандомного выбора индекса массива с цветами
}

function createField(size){   //Создание поля
	for (let tblRow = 0; tblRow < size; tblRow++){  //Создание строк таблицы
		let tr = document.createElement('tr');
		for (let tblColl = 0; tblColl < size; tblColl++){   //Цикл создания ячеек для каждой строки таблицы
			let td = document.createElement('td');   //Создает ячейку для строки таблицы
			td.classList.add(random(colors))   //Рандомный цвет ячейки
			td.addEventListener("click", step)   //Добавление ячейки выполнение функции при нажатии
			tr.appendChild(td);   //добавляет ячейку в строку таблицы
		}
	table.appendChild(tr);   //Создает строку таблицы
	}
}

function step() {   //Функция шагов при нажатии
	stepCount += 1;   //При нажатии увеличивается количество шагов
    let color = colors.indexOf(this.classList.item(0))   //Индекс цвета ячейки
	if (color == colors.length-1) this.classList.add(colors[0])  //Если цвет ячейки последний в массиве, то берется цвет из начала массива
    else this.classList.add(colors[color+1]) //Иначе просто просто при нажатии цвета идут друг за другом
	this.classList.remove(colors[color]) //Удаляет предыдущее имя класса   
	if (isVictory(cells)) {   //Если существует функция победы
		alert("ВЫ ПОБЕДИЛИ! Ваше количество шагов: "+ stepCount); // вывод победного окна с кол-вом сделанных шагов
	}
}

function isVictory(cells) {   //Условия победы
	let cellsColor = [];
	for (let cell of cells) cellsColor.push(cell.classList.item(0)); //Пихаем все названия классов ячеек в массив
	for (let i = 0; i < cellsColor.length; i++) { //Перебираем ячейки
        while(cellsColor[i] != cellsColor[0]) return false; //Возвращает ложь, пока хоть какой-то класс ячейки не равен классу первой ячейки
    } 
	return true; //Возвращает истину, если все именя классов равны
}
createField(userSize)   //Вызов функции для создания поля
let cells = document.querySelectorAll('td');   //Выбираем все поле